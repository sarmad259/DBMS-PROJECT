from django import forms
from .models import User

class UserForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['Name', 'Phone', 'Email', 'Password', 'BloodGroup', 'CNIC', 'Address']
        widgets = {
            'Name': forms.TextInput(attrs={
                'placeholder': 'Your Name',
                'class': 'form-control',
            }),
            'Phone': forms.TextInput(attrs={
                'placeholder': 'Your Phone',
                'class': 'form-control',
                'type': 'tel',
                'pattern': '[0-9]{11,13}',
                'title': 'Enter a valid phone number',
            }),
            'Email': forms.EmailInput(attrs={
                'placeholder': 'Your Email',
                'class': 'form-control',
            }),
            'Password': forms.PasswordInput(attrs={
                'placeholder': 'Your Password',
                'class': 'form-control',
            }),
            'BloodGroup': forms.TextInput(attrs={
                'placeholder': 'Your Blood Group',
                'class': 'form-control',
            }),
            'CNIC': forms.TextInput(attrs={
                'placeholder': 'Your CNIC',
                'class': 'form-control',
            }),
            'Address': forms.Textarea(attrs={
                'placeholder': 'Your Address',
                'class': 'form-control',
                'rows': 3,
            }),
        }
