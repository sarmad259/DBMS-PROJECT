from django.db import models

DAY_CHOICES = [
    ('monday', 'Monday'),
    ('tuesday', 'Tuesday'),
    ('wednesday', 'Wednesday'),
    ('thursday', 'Thursday'),
    ('friday', 'Friday'),
    ('saturday', 'Saturday'),
    ('sunday', 'Sunday'),
]

class User(models.Model):
    Id = models.AutoField(primary_key=True)
    Name = models.CharField(max_length=50)
    Phone = models.CharField(max_length=100)
    Email = models.EmailField()
    Password = models.CharField(max_length=128)
    BloodGroup = models.CharField(max_length=5)
    CNIC = models.CharField(max_length=15)
    Address	= models.TextField()
    class Meta:
        db_table = 'USER'

class Employee(models.Model):
    Emp_ID = models.CharField(max_length=15,primary_key=True,unique=True)
    Designation = models.CharField(max_length=100)
    Salary = models.DecimalField(max_digits=15, decimal_places=2)
    Experience = models.CharField(max_length=50)

    Name = models.CharField(max_length=40)
    class Meta:
        db_table = 'Employee_Info_View'

class Booking(models.Model):
    Id = models.AutoField(primary_key=True)
    Receptionist = models.CharField(max_length=20)
    Doctor = models.CharField(max_length=50)
    Patient	= models.CharField(max_length=50)
    Appointment_Time = models.TimeField()
    Appointment_Date = models.DateField()
    Status = models.CharField(max_length=50)
    class Meta:
        db_table = 'Booked_View'

class Receptionist(models.Model):
    Id	= models.AutoField(primary_key=True)
    Name = models.CharField(max_length=50)
    Phone = models.CharField(max_length=15)
    class Meta:
        db_table = 'Receptionist_Info_View'

class Patient(models.Model):
    Id = models.AutoField(primary_key=True)
    Name = models.CharField(max_length=100)
    Phone = models.CharField(max_length=15)
    DOB = models.TimeField()
    History = models.TextField()
    Gender = models.CharField(max_length=15)
    BloodGroup = models.CharField(max_length=15)
    CNIC = models.CharField(max_length=20)
    Address = models.TextField()
    class Meta:
        db_table = 'Patient_Info_View'

class Nurse(models.Model):
    Id = models.AutoField(primary_key=True)
    Nurse = models.CharField(max_length=100)
    Experience = models.CharField(max_length=100)
    Doctor = models.CharField(max_length=100)
    class Meta:
        managed = False
        db_table = 'Nurse_Info_View'

class Appointment(models.Model):
    Id = models.AutoField(primary_key=True)
    Appointment_Time = models.TimeField()
    Appointment_Date = models.DateField()
    DOB = models.CharField(max_length=100)
    Patient = models.CharField(max_length=100)
    Doctor = models.CharField(max_length=100)
    Status = models.CharField(max_length=50)
    class Meta:
        managed = False
        db_table = 'Appointment_view'

class Payment(models.Model):
    Id = models.AutoField(primary_key=True)
    Name = models.CharField(max_length=200)
    Type = models.CharField(max_length=150)	
    Pay_date_time = models.DateTimeField()
    Status = models.CharField(max_length=100)
    class Meta:
        managed = False
        db_table = 'Payments_view'

class Cash_Payment(models.Model):
    Id = models.AutoField(primary_key=True)
    Name = models.CharField(max_length=200)
    Type = models.CharField(max_length=150)	
    Pay_date_time = models.DateTimeField()
    Status = models.CharField(max_length=100)
    class Meta:
        managed = False
        db_table = 'Cash_Payments_view'

class Online_Payment(models.Model):
    Id = models.AutoField(primary_key=True)
    Name = models.CharField(max_length=200)
    Type = models.CharField(max_length=150)	
    Pay_date_time = models.DateTimeField()
    Status = models.CharField(max_length=100)
    class Meta:
        managed = False
        db_table = 'Online_Payments_view'

class Doctor(models.Model):
    Doctor_Id = models.AutoField(primary_key=True)
    Name = models.CharField(max_length=200)
    Phone = models.CharField(max_length=200)
    Experience = models.CharField(max_length=200)
    Specialization = models.CharField(max_length=200)
    Availability_Start_Time = models.TimeField()
    Availability_End_Time = models.TimeField()
    Availability_Day = models.CharField(max_length=100)
    Type = models.CharField(max_length=50)
    class Meta:
        db_table = 'Doctor_Info_View'
