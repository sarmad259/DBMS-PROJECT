from django.contrib import admin
from django.urls import path
from myapp import views

urlpatterns = [
    path('',views.home, name='home'),
    path('home',views.home, name='home'),
    path('about',views.about,name='about'),
    path('doctor',views.doctor, name='doctor'),
    path('login',views.login,name='login'),
    path('signup',views.signup,name='login'),
    
    path('nurse',views.nurse,name='nurse'),
    path('employee',views.employee,name='employee'),
    path('appointment',views.appointment,name='appointment'),
    path('patient',views.patient,name='patient'),
    path('receptionist',views.receptionist,name='receptionist'),
    path('payment',views.payment,name='payment'),
    path('booking',views.booking,name='booking'),
    path('user',views.user,name='user'),
    path('delete_user', views.delete_user, name='delete_user'),
    path('edit_user/<str:user_id>',views.edit_user, name='edit_user'),
    path('add_Employee',views.add_employee, name='addemployee'),
]