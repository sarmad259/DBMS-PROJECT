from django.shortcuts import render,redirect,get_object_or_404
from myapp import models
from django.db import connection
from django.contrib import messages
from django.contrib.auth.hashers import make_password
from myapp.models import Doctor,Payment,Appointment,Cash_Payment,Online_Payment,Nurse,Patient,Receptionist,Booking,User,Employee
# Create your views here.

# Data Insertion Models

def home(request):
    return render(request,'home.html')

def about(request):
    return render(request,'about.html')

def login(request):
    return render(request, 'login.html')

def details(request, role):
    return render(request, 'details.html', {'role': role})

def add_employee(request):
    if request.method == 'POST':
        user_id = request.POST['user_id']
        user = User.objects.get(id=user_id)

    if Employee.objects.filter(user = user.Id).exists():
        messages.error(request, 'This user already has been associated employee.')
    else:
        employee = Employee(
            destination = request.POST.get('destination'),
            salary = request.POST.get('salary'),
            experience = request.POST.get('experience'),
            user=user
        )
        employee.save()
        messages.error("Employee added Successfully.")
        return redirect('add_employee')
    
    users = User.objects.all()
    return render(request, 'addemployee.html',{'users':users})

def signup(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        phone = request.POST.get('phone')
        email = request.POST.get('email')
        password = request.POST.get('pass')
        bloodGroup = request.POST.get('blood')
        cnic = request.POST.get('cnic')
        address = request.POST.get('address')
        role = request.POST.get('role')
        repassword = request.POST.get('re-pass')

        hashed_password = make_password(password)
        
        if not User.objects.filter(Phone=phone, Email=email, CNIC=cnic).exists():
            # if password == repassword:
                user = User(Name=name, Phone=phone, Email=email, Password=hashed_password, BloodGroup=bloodGroup, CNIC=cnic, Address=address)
                user.save()
                return render(request, 'details.html', {'role': role, 'user_id': id})
        else:
            messages.error(request,"Phone, Email or CNIC has been already registered")

    return render(request, 'signup.html')

def save_details(request, role):
    if request.method == 'POST':
        user_id = request.POST.get('user_id')
        user = User.objects.get(id=user_id)

        if role == 'doctor':
            specialization = request.POST.get('specialization', '')
            availability_start_time = request.POST.get('availability_start_time', '')
            availability_end_time = request.POST.get('availability_end_time', '')
            availability_day = request.POST.get('availability_day', '')

            doctor = Doctor(
                User_Id=user,
                Specialization = specialization,
                Availability_Start_Time = availability_start_time,
                Availability_End_Time = availability_end_time,
                Availability_Day = availability_day
            )
            doctor.save()

        elif role == 'user':
            # Save user-specific details if any
            pass
        elif role == 'nurse':
            # Save nurse-specific details
            pass
        elif role == 'receptionist':
            # Save receptionist-specific details
            pass
        return redirect(request.META.get('HTTP_REFERER', '/'),{'error_message':'Data added successfully!'}) 

    return render(request, 'details.html', {'role': role})


# Data Deletion 

def delete_user(request):
    if request.method == 'POST':
        user_id = request.POST.get('user_id')
        
        user = User.objects.get(Id=user_id)
        user.delete()
        return redirect(request.META.get('HTTP_REFERER', '/'))
    
# Data Updation

def edit_user(request, user_id):
    user = get_object_or_404(User, Id=user_id)

    if request.method == 'POST':
        user.Name = request.POST.get('name')
        user.Phone = request.POST.get('phone')
        user.Email = request.POST.get('email')
        user.Password = request.POST.get('pass')  
        user.BloodGroup = request.POST.get('blood')
        user.CNIC = request.POST.get('cnic')
        user.Address = request.POST.get('address')
        
        user.save()

    return render(request, 'edit.html', {'user': user})


        
# Data Fetching 

def employee(request):
    data = Employee.objects.all()
    return render(request, 'employee.html',{'employees':data})

def user(request):
    data = User.objects.all()
    return render(request, 'user.html',{'users':data})

def booking(request):
    data = Booking.objects.all()
    return render(request, 'booking.html',{'bookings':data})

def patient(request):
    patients = Patient.objects.all()
    return render(request, 'patient.html',{'patients':patients})

def receptionist(request):
    receptionists = Receptionist.objects.all()
    return render(request, 'receptionist.html',{'receptionists':receptionists})

def nurse(request):
    nurses = Nurse.objects.all()
    return render(request, 'nurse.html',{'nurses':nurses})

def appointment(request):
    appointments = Appointment.objects.all()
    return render(request, 'appointment.html',{'appointments':appointments})

def payment(request):
    payments = Payment.objects.all()
    cash_payments = Cash_Payment.objects.all()
    online_payments = Online_Payment.objects.all()
    return render(request, 'payment.html',{'payments':payments,'cp':cash_payments,'op':online_payments})

def doctor(request):
    doctors = Doctor.objects.all()
    return render(request, "doctor.html",{'doctors':doctors})